   gsap.registerPlugin(ScrollTrigger);

        class SmoothHorizontalScroll {
            constructor() {
                this.gallery = document.getElementById('gallery');
                this.progressFill = document.getElementById('progressFill');
                this.init();
            }

            init() {
                this.setupSmoothScroll();
                this.setupProgressBar();
                this.setupAnimations();
            }

            setupSmoothScroll() {
                const galleryWidth = this.gallery.scrollWidth;
                const windowWidth = window.innerWidth;
                const scrollDistance = galleryWidth - windowWidth;

                gsap.to(this.gallery, {
                    x: -scrollDistance,
                    ease: "none",
                    scrollTrigger: {
                        trigger: ".scroll-section",
                        start: "top top",
                        end: "bottom bottom",
                        scrub: 1, 
                        pin: ".horizontal-container",
                        anticipatePin: 1,
                        onUpdate: (self) => {
                            const progress = self.progress * 100;
                            gsap.to(this.progressFill, {
                                height: `${progress}%`,
                                duration: 0.1,
                                ease: "none"
                            });
                        }
                    }
                });

                gsap.utils.toArray('.image-card img').forEach((img, index) => {
                    const speed = 0.3 + (index % 3) * 0.1;
                    
                    gsap.to(img, {
                        x: `${speed * 50}px`,
                        ease: "none",
                        scrollTrigger: {
                            trigger: ".scroll-section",
                            start: "top bottom",
                            end: "bottom top",
                            scrub: 1
                        }
                    });
                });
            }

            setupProgressBar() {
                
            }

            setupAnimations() {
                const tl = gsap.timeline();
                
                tl.from('.header h1', {
                    opacity: 0,
                    y: -50,
                    duration: 1.2,
                    ease: "power3.out"
                })
                .from('.header p', {
                    opacity: 0,
                    y: -30,
                    duration: 1,
                    ease: "power3.out"
                }, "-=0.8")
                .from('.image-card', {
                    opacity: 0,
                    y: 100,
                    rotationY: -20,
                    duration: 1.5,
                    stagger: 0.1,
                    ease: "power3.out"
                }, "-=0.6")
                .from('.scroll-progress, .scroll-hint, .mouse-indicator', {
                    opacity: 0,
                    scale: 0.8,
                    duration: 1,
                    stagger: 0.1,
                    ease: "power3.out"
                }, "-=1");

                gsap.utils.toArray('.image-card').forEach(card => {
                    const img = card.querySelector('img');
                    const overlay = card.querySelector('.card-overlay');
                    
                    card.addEventListener('mouseenter', () => {
                        gsap.to(img, {
                            scale: 1.15,
                            duration: 0.6,
                            ease: "power2.out"
                        });
                        
                        gsap.to(overlay, {
                            y: 0,
                            duration: 0.5,
                            ease: "power3.out"
                        });
                    });
                    
                    card.addEventListener('mouseleave', () => {
                        gsap.to(img, {
                            scale: 1,
                            duration: 0.6,
                            ease: "power2.out"
                        });
                        
                        gsap.to(overlay, {
                            y: '100%',
                            duration: 0.5,
                            ease: "power3.out"
                        });
                    });
                });
            }
        }

        window.addEventListener('DOMContentLoaded', () => {
            new SmoothHorizontalScroll();
        });

        window.addEventListener('resize', () => {
            ScrollTrigger.refresh();
        });